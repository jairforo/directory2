<?php

return array(
	'item' => array(
		'label'    => __('Item', 'ait-toolkit'),
		'type'     => 'post-select',
		'postType' => 'ait-item',
		'help'     => __('Related Item', 'ait-toolkit'),
	),
);
